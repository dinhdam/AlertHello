function MinScore()

